# Tracking Build - Pertemuan 4 (Praktikum AVR ITIA730591)

Tracking AR dengan MindAR 1.2.5 dan Three.js 0.160.0: image tracking dan face tracking.

- Nama / NIM : (isi)
- URL GitHub Pages : (isi, contoh https://nama-akun.github.io/nama-repo/tracking-build/)

## Struktur folder

```
tracking-build/
├── index.html            # menu + cek lingkungan (secure context, getUserMedia)
├── image-tracking.html   # Demo 1 (halaman)
├── face-tracking.html    # Demo 2 (halaman)
├── src/                  # kode yang Anda tulis
│   ├── styles.css        # gaya bersama
│   ├── common.js         # setStatus, checkCameraSupport, setupStartButton
│   ├── image-demo.js     # image tracking: Deadpool mini (bentuk dasar Three.js)
│   ├── face-demo.js      # face tracking: topeng Deadpool sebagai tekstur face mesh (ikut ekspresi wajah)
│   └── face-canonical.js # posisi netral 468 titik wajah (data acuan pemetaan tekstur)
├── vendor/               # pustaka lokal (jangan diubah/diganti versi)
│   ├── three/            # Three.js r160 + addons/renderers/CSS3DRenderer.js
│   └── mindar/           # bundel MindAR image & face
├── targets/target-card.mind   # target gambar terkompilasi
├── assets/images/deadpool-mask.png     # gambar topeng untuk face tracking
├── assets/images/target-card.png     # target bawaan (sudah dikompilasi -> .mind)
├── assets/images/target-deadpool.png # target tema Deadpool (BELUM dikompilasi)
├── docs/
│   ├── test-cases.md     # functional test (isi hasil aktual)
│   ├── device-matrix.md  # matriks perangkat
│   └── evidence/         # screenshot / video bukti uji
└── .nojekyll             # agar GitHub Pages menyajikan semua berkas apa adanya
```

## Cara menjalankan

```bash
cd tracking-build
python -m http.server 8080      # atau: python3 -m http.server 8080
```
Buka http://localhost:8080 (harus localhost/HTTPS agar kamera diizinkan).
Face tracking butuh internet (model wajah diunduh dari CDN).

## Memakai target-deadpool.png (opsional)

`target-card.mind` tetap dipakai secara default karena sudah pasti cocok dengan
`target-card.png`. Agar kartu bertema Deadpool bisa dilacak, gambarnya harus dikompilasi dulu:

1. Buka https://hiukim.github.io/mind-ar-js-doc/tools/compile, unggah
   `assets/images/target-deadpool.png`, tekan Start, lalu unduh `targets.mind`.
2. Simpan sebagai `targets/target-deadpool.mind`.
3. Di `src/image-demo.js` ubah dua baris:
   ```js
   const TARGET_SRC = './targets/target-deadpool.mind';
   const TARGET_ASPECT = 700 / 1000; // tinggi/lebar gambar (1000x700 px)
   ```
4. Muat ulang (Ctrl+Shift+R) dan arahkan kamera ke gambar tersebut.

## Hasil

(isi ringkasan hasil uji aktual)

## Keterbatasan

- MindAR melacak target gambar dan wajah; bukan spatial mapping lingkungan.
- (tambahkan temuan Anda)

## Masalah dan investigasi

(isi satu masalah/keterbatasan dan cara Anda menyelidikinya)
